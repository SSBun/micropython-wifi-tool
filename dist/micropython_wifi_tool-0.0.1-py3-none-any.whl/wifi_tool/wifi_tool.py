class WifiTool:
    @staticmethod
    def connectWifi():
        print('Ready to connect wifi ...')
